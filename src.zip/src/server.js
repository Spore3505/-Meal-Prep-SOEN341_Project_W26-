const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(__dirname));
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "register.html"));
});
app.post("/register", (req, res) => {
    const { username, password } = req.body;

    fs.readFile("users.txt", "utf8", (err, data) => {
        if (err && err.code !== "ENOENT") {
            return res.status(500).send("Error reading users file");
        }
        const users = data || "";
        if (username.length < 6) {
            return res.status(400).send("Username must be at least 6 characters long");
        }
        if (users.includes(`Username: ${username},`)) {
            return res.status(400).send("Username already exists");
        }
        if (password.length < 6) {
            return res
                .status(400)
                .send("Password must be at least 6 characters long");
        }
        const line = `Username: ${username}, Password: ${password}\n`;
        fs.appendFile("users.txt", line, (err) => {
            if (err) {
                res.status(500).send("Error saving user");
            } else {
                res.send("User registered successfully");
            }
        });
    });
});



app.post("/login", (req, res) => {
    const { username, password } = req.body;

    fs.readFile("users.txt", "utf8", (err, data) => {
        if (err) {
            return res.status(500).send("Error reading users file");
        }

        const users = data.split("\n");

        for (let line of users) {
            if (
                line.includes(`Username: ${username}, Password: ${password}`)
            ) {
                return res.send("Login successful");
            }
        }

        res.status(401).send("Invalid username or password");
    });
});
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
